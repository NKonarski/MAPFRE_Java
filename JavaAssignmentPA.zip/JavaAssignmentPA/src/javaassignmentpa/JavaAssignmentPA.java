package javaassignmentpa;

/**
 * @Author Name: Nicole Konarski
 * @Date: May 6, 2019
 * @Description: This program allows the user to implement a queue with a max of
 * 10 doubles. The items in the queue are removed in FIFO fashion.
 */
//Imports
import java.util.*;
import java.util.Scanner;

//Begin Class JavaAssignmentPA
public class JavaAssignmentPA {

    //Begin Main Method
    public static void main(String[] args) {
        //create deque object
        Deque<Integer> list = new LinkedList<>();
        //create scanner object
        Scanner input = new Scanner(System.in);
        int choice = 0;
        Integer addedItem = null;
        boolean flag = false;
        char again;

        do {
            do {
                try {
                    flag = false;

                    System.out.println("Select one of the following: \n");
                    System.out.println("1. Enter a number into the queue");
                    System.out.println("2. Remove a number from the queue");
                    System.out.println("3. Exit");


                    System.out.print("\nPlease enter choice: \n");

                    choice = input.nextInt();

                    //validate input
                    if (choice != 1 && choice != 2 && choice != 3) {
                        System.out.println("You have entered an invalid choice.");
                        flag = true;
                    }

                } catch (InputMismatchException ex) {
                    System.err.print("ERROR: That is not a number! Try again "
                            + "please.");
                    flag = true;
                }

                input.nextLine();
            } while (flag);

            //add integer to queue
            if (choice == 1) {
                if (list.size() <= 9) {
                                                            
                    try {
                        System.out.print("Enter input: ");
                        addedItem = input.nextInt();
                        list.add(addedItem);
                    } catch (InputMismatchException ex) {
                        System.err.print("ERROR: That is not a number! Try again "
                                + "please.");
                    }

                } else {
                    System.out.println("Sorry. Currently the queue is full. "
                            + "Please try again later when at least one dequeue "
                            + "is performed. ");
                }
            } //remove integer number from queue
            else if (choice == 2) {
                if (list.size() >= 1) {
                    System.out.println("You are removing " + list.peekFirst() + 
                            " from the list\n");
                    list.removeFirst();
                } else {
                    System.out.println("Sorry. Currently the queue is empty. "
                            + "Please try again later when at least one enqueue "
                            + "is performed. ");
                }
            } else {
                System.out.println("Exiting.");
                System.exit(0);
            }

            do {
                System.out.print("Enter more inputs? or Remove inputs? (Y for "
                        + "Yes and N for No) ");
                again = input.next().charAt(0);
                if (again == 'y' || again == 'Y') {
                    flag = false;
                } else if (again == 'n' || again == 'N') {
                    flag = false;
                } else {
                    System.out.println("Invalid entry!");
                    flag = true;
                }
            } while (flag);

        } while (again == 'y' || again == 'Y');

        System.out.println("Goodbye!");

    } //End Main Method
} //End Class JavaAssignmentPA